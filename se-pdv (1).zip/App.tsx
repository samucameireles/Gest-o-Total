import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { POS } from './components/POS';
import { Kitchen } from './components/Kitchen';
import { Inventory } from './components/Inventory';
import { Logistics } from './components/Logistics';
import { Reports } from './components/Reports';
import { Motoboys } from './components/Motoboys';
import { Settings } from './components/Settings';
import { CRM } from './components/CRM';
import { Order, CartItem, OrderType, PaymentMethod, Ingredient, OrderStatus, Driver, Product, NeighborhoodFee, DeliveryDetails, StoreSettings, Unit, Customer, Coupon, WasteLog, AddOn } from './types';
import { INITIAL_INVENTORY, RECIPES, DRIVERS, PRODUCTS, INITIAL_ADDONS } from './constants';
import { Store, ArrowRight, Plus, Trash2, Edit2, Save } from 'lucide-react';

export default function App() {
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);
  const [activeTab, setActiveTab] = useState('pos');

  const [units, setUnits] = useState<Unit[]>(() => {
    const saved = localStorage.getItem('se_units');
    return saved ? JSON.parse(saved) : [
      { id: 'u1', name: 'Diego Lanches', logoUrl: '' },
      { id: 'u2', name: 'O Glutão Lanches', logoUrl: '' }
    ];
  });

  // --- Unit-Scoped State ---
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderSequence, setOrderSequence] = useState<number>(1);
  const [inventory, setInventory] = useState<Ingredient[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [neighborhoodFees, setNeighborhoodFees] = useState<NeighborhoodFee[]>([]);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>({ name: '', logoUrl: '' });
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [wasteLogs, setWasteLogs] = useState<WasteLog[]>([]);
  const [addOns, setAddOns] = useState<AddOn[]>([]); // V12: AddOns State

  const [isEditingUnits, setIsEditingUnits] = useState(false);
  const [newUnitName, setNewUnitName] = useState('');
  
  useEffect(() => {
    localStorage.setItem('se_units', JSON.stringify(units));
  }, [units]);

  const handleCreateUnit = () => {
    if (newUnitName) {
      const newUnit: Unit = { id: Math.random().toString(36).substr(2, 5), name: newUnitName, logoUrl: '' };
      setUnits([...units, newUnit]);
      setNewUnitName('');
    }
  };

  const handleDeleteUnit = (id: string) => {
    if (window.confirm("Tem certeza? Isso não apaga os dados da unidade, apenas o acesso.")) {
      setUnits(units.filter(u => u.id !== id));
    }
  };

  const handleUpdateUnit = (id: string, name: string) => {
    setUnits(units.map(u => u.id === id ? { ...u, name } : u));
  };

  // --- Persistence ---
  useEffect(() => {
    if (!selectedUnit) return;
    const prefix = `se_${selectedUnit.id}_`;
    const load = (key: string, def: any) => {
      const s = localStorage.getItem(prefix + key);
      return s ? JSON.parse(s) : def;
    };

    setOrders(load('orders', []));
    setOrderSequence(parseInt(localStorage.getItem(prefix + 'order_seq') || '1'));
    setInventory(load('inventory', INITIAL_INVENTORY));
    
    // Load products and ensure new fields exist
    const loadedProducts = load('products', PRODUCTS);
    setProducts(loadedProducts.map((p: any) => ({ 
        ...p, 
        allowObservations: p.allowObservations ?? true,
        recipe: p.recipe || [],
        allowedAddOns: p.allowedAddOns || [] // Ensure allowedAddOns exists
    })));

    setDrivers(load('drivers', DRIVERS));
    setNeighborhoodFees(load('fees', [{ id: '1', name: 'Centro', price: 5.00 }]));
    setStoreSettings(load('settings', { name: selectedUnit.name, logoUrl: selectedUnit.logoUrl }));
    setCustomers(load('customers', []));
    setCoupons(load('coupons', []));
    setWasteLogs(load('wasteLogs', []));
    setAddOns(load('addOns', INITIAL_ADDONS)); // V12: Load AddOns
  }, [selectedUnit]);

  const save = (key: string, data: any) => {
    if (selectedUnit) {
       localStorage.setItem(`se_${selectedUnit.id}_${key}`, JSON.stringify(data));
    }
  };

  useEffect(() => save('orders', orders), [orders, selectedUnit]);
  useEffect(() => { if(selectedUnit) localStorage.setItem(`se_${selectedUnit.id}_order_seq`, orderSequence.toString()) }, [orderSequence, selectedUnit]);
  useEffect(() => save('inventory', inventory), [inventory, selectedUnit]);
  useEffect(() => save('products', products), [products, selectedUnit]);
  useEffect(() => save('drivers', drivers), [drivers, selectedUnit]);
  useEffect(() => save('fees', neighborhoodFees), [neighborhoodFees, selectedUnit]);
  useEffect(() => save('settings', storeSettings), [storeSettings, selectedUnit]);
  useEffect(() => save('customers', customers), [customers, selectedUnit]);
  useEffect(() => save('coupons', coupons), [coupons, selectedUnit]);
  useEffect(() => save('wasteLogs', wasteLogs), [wasteLogs, selectedUnit]);
  useEffect(() => save('addOns', addOns), [addOns, selectedUnit]);

  // --- Core Actions ---

  const handlePlaceOrder = (items: CartItem[], type: OrderType, paymentMethod: PaymentMethod, deliveryDetails?: DeliveryDetails, dineInName?: string, tableName?: string, sendToKitchenOnly?: boolean) => {
    const currentId = orderSequence;
    setOrderSequence(prev => prev + 1);

    // V12: Calculate Total including AddOns
    const orderTotal = items.reduce((acc, item) => {
        const addOnsTotal = item.selectedAddOns?.reduce((sum, addon) => sum + addon.price, 0) || 0;
        return acc + ((item.price + addOnsTotal) * item.quantity);
    }, 0);

    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9),
      displayId: currentId,
      items,
      total: orderTotal,
      discount: 0,
      
      status: 'PREPARING', 
      isPaid: paymentMethod !== 'PENDING', 
      kitchenDismissed: false, 

      type,
      paymentMethod,
      deliveryDetails,
      customerName: type === 'DELIVERY' ? deliveryDetails?.customerName : dineInName,
      tableName,
      createdAt: Date.now()
    };

    setOrders(prev => [newOrder, ...prev]);

    // Inventory Deduction
    const newInventory = [...inventory];
    items.forEach(item => {
      let productRecipe = item.recipe;
      if (!productRecipe || productRecipe.length === 0) {
          productRecipe = RECIPES[item.id];
      }
      if (productRecipe) {
        productRecipe.forEach(recipeItem => {
          const ingredientIndex = newInventory.findIndex(ing => ing.id === recipeItem.ingredientId);
          if (ingredientIndex > -1) {
            newInventory[ingredientIndex].currentStock -= (recipeItem.amount * item.quantity);
          }
        });
      }
    });
    setInventory(newInventory);
    
    // CRM
    if (deliveryDetails) {
        const exists = customers.find(c => c.phone === deliveryDetails.phone);
        if (!exists) {
            handleAddCustomer({
                name: deliveryDetails.customerName,
                phone: deliveryDetails.phone,
                street: deliveryDetails.street,
                number: deliveryDetails.number,
                neighborhood: deliveryDetails.neighborhood,
                lastOrder: Date.now()
            });
        }
    }
  };

  const handlePayOrder = (orderId: string, paymentMethod: PaymentMethod, discount: number) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          isPaid: true,
          paymentMethod,
          discount,
          total: o.total - discount
        };
      }
      return o;
    }));
  };

  const handleUpdateStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const handleKitchenDismiss = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, kitchenDismissed: true } : o));
  }

  const handleLogWaste = (ingredientId: string, amount: number, reason: string) => {
      const ing = inventory.find(i => i.id === ingredientId);
      if(!ing) return;
      const log: WasteLog = {
          id: Math.random().toString(),
          ingredientName: ing.name,
          unit: ing.unit,
          amount,
          reason,
          date: Date.now()
      };
      setWasteLogs(prev => [log, ...prev]);
      setInventory(prev => prev.map(i => i.id === ingredientId ? { ...i, currentStock: i.currentStock - amount } : i));
  };

  // --- Entity Management ---
  const handleAssignDriver = (orderId: string, driverId: string) => setOrders(prev => prev.map(o => o.id === orderId ? { ...o, assignedDriverId: driverId } : o));
  const handleUpdateStock = (id: string, newAmount: number) => setInventory(prev => prev.map(item => item.id === id ? { ...item, currentStock: newAmount } : item));
  const handleUpdateIngredientName = (id: string, newName: string, newUnit: string) => setInventory(prev => prev.map(item => item.id === id ? { ...item, name: newName, unit: newUnit } : item));
  
  const handleDeliveryComplete = (orderId: string, status: OrderStatus) => {
      const order = orders.find(o => o.id === orderId);
      if (status === 'DELIVERED' && order && order.assignedDriverId) {
          let fee = 5.00;
          if (order.deliveryDetails) {
             const neighborhoodFee = neighborhoodFees.find(nf => order.deliveryDetails?.neighborhood.toLowerCase().includes(nf.name.toLowerCase()));
             if (neighborhoodFee) fee = neighborhoodFee.price;
          }
          setDrivers(prev => prev.map(d => d.id === order.assignedDriverId ? { ...d, deliveriesCount: d.deliveriesCount + 1, commissionTotal: d.commissionTotal + fee, history: [...(d.history || []), order.displayId] } : d));
      }
      handleUpdateStatus(orderId, status);
  };

  const handleAddDriver = (name: string) => setDrivers(prev => [...prev, { id: Math.random().toString(36), name, deliveriesCount: 0, commissionTotal: 0, active: true, history: [] }]);
  const handleRemoveDriver = (id: string) => setDrivers(prev => prev.filter(d => d.id !== id));
  const handleUpdateFee = (neighborhood: string, price: number) => {
      const exists = neighborhoodFees.find(f => f.name.toLowerCase() === neighborhood.toLowerCase());
      if (exists) { setNeighborhoodFees(prev => prev.map(f => f.name.toLowerCase() === neighborhood.toLowerCase() ? { ...f, price } : f)); } 
      else { setNeighborhoodFees(prev => [...prev, { id: Math.random().toString(), name: neighborhood, price }]); }
  };
  const handleRemoveFee = (id: string) => setNeighborhoodFees(prev => prev.filter(f => f.id !== id));
  const handleAddIngredient = (name: string, unit: string) => setInventory(prev => [...prev, { id: Math.random().toString(), name, unit, currentStock: 0, minThreshold: 5 }]);
  const handleRemoveIngredient = (id: string) => setInventory(prev => prev.filter(i => i.id !== id));
  
  const handleAddProduct = (prod: Omit<Product, 'id'>) => setProducts(prev => [...prev, { ...prod, id: Math.random().toString() }]);
  const handleRemoveProduct = (id: string) => setProducts(prev => prev.filter(p => p.id !== id));
  
  const handleAddCustomer = (c: Omit<Customer, 'id'>) => setCustomers(prev => [...prev, { ...c, id: Math.random().toString() }]);
  const handleRemoveCustomer = (id: string) => setCustomers(prev => prev.filter(c => c.id !== id));
  const handleAddCoupon = (code: string, percent: number) => setCoupons(prev => [...prev, { id: Math.random().toString(), code, discountPercent: percent, active: true }]);
  const handleRemoveCoupon = (id: string) => setCoupons(prev => prev.filter(c => c.id !== id));

  // V12: AddOn Handlers
  const handleAddAddOn = (name: string, price: number) => setAddOns(prev => [...prev, { id: Math.random().toString(), name, price }]);
  const handleRemoveAddOn = (id: string) => setAddOns(prev => prev.filter(a => a.id !== id));

  if (!selectedUnit) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center p-6 font-sans">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-12 animate-in slide-in-from-bottom-5 fade-in duration-700">
             <div className="inline-flex items-center justify-center w-24 h-24 bg-white rounded-3xl shadow-xl shadow-slate-200 mb-6 overflow-hidden border border-slate-100">
                 <span className="text-4xl font-extrabold text-blue-600 tracking-tighter">SE</span>
             </div>
             <h1 className="text-4xl font-extrabold text-slate-800 mb-3 tracking-tight">SE PDV - Enterprise</h1>
             <p className="text-slate-500 text-lg">Selecione ou crie uma unidade para gerenciar</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {units.map((unit, idx) => (
              <div key={unit.id} className="bg-white group p-8 rounded-3xl border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] hover:shadow-xl text-left relative transition-all" style={{animationDelay: `${idx * 100}ms`}}>
                {isEditingUnits ? (
                   <div className="flex gap-2">
                       <input className="flex-1 border-b border-slate-300 outline-none font-bold text-slate-800" defaultValue={unit.name} onBlur={(e) => handleUpdateUnit(unit.id, e.target.value)} />
                       <button onClick={() => handleDeleteUnit(unit.id)} className="text-red-500 hover:bg-red-50 p-2 rounded"><Trash2 size={16}/></button>
                   </div>
                ) : (
                  <button onClick={() => { setSelectedUnit(unit); setStoreSettings(s => ({...s, name: unit.name})) }} className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-5">
                      <div className={`w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg`}>
                        <Store size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-slate-800 group-hover:text-blue-600 transition-colors">{unit.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-slate-400 mt-1"><div className="w-2 h-2 rounded-full bg-green-500"></div> Online</div>
                      </div>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-slate-50 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center transition-colors"><ArrowRight size={20} /></div>
                  </button>
                )}
              </div>
            ))}
            <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center p-6 hover:border-blue-400 hover:bg-blue-50 transition-colors cursor-pointer group" onClick={() => !isEditingUnits && document.getElementById('new-unit-input')?.focus()}>
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-slate-400 group-hover:text-blue-600 shadow-sm mb-3"><Plus size={24} /></div>
                <input id="new-unit-input" placeholder="Criar Nova Unidade" className="bg-transparent text-center font-bold text-slate-600 placeholder-slate-400 outline-none w-full" value={newUnitName} onChange={e => setNewUnitName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleCreateUnit()} />
                {newUnitName && <button onClick={handleCreateUnit} className="mt-2 text-xs bg-blue-600 text-white px-3 py-1 rounded-full font-bold">Criar</button>}
            </div>
          </div>
          <div className="text-center">
              <button onClick={() => setIsEditingUnits(!isEditingUnits)} className="text-slate-400 hover:text-slate-600 text-sm font-medium flex items-center justify-center gap-2 mx-auto">
                  {isEditingUnits ? <><Save size={14}/> Concluir Edição</> : <><Edit2 size={14}/> Gerenciar Lista</>}
              </button>
          </div>
        </div>
      </div>
    );
  }

  // Active Open Tabs for POS: Dine-in orders that are not fully Paid
  const openTabs = orders.filter(o => 
    o.type === 'DINE_IN' && 
    !o.isPaid // V10: Show unpaid tables, regardless of kitchen status
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'pos':
        return <POS products={products} onPlaceOrder={handlePlaceOrder} onPayOrder={handlePayOrder} inventory={inventory} customers={customers} onAddCustomer={handleAddCustomer} activeOrders={openTabs} coupons={coupons} addOns={addOns} />;
      case 'kitchen':
        return <Kitchen orders={orders} onUpdateStatus={handleUpdateStatus} onKitchenDismiss={handleKitchenDismiss} />;
      case 'logistics':
        return <Logistics orders={orders} drivers={drivers} onAssignDriver={handleAssignDriver} onUpdateStatus={handleDeliveryComplete} />;
      case 'motoboys':
        return <Motoboys drivers={drivers} onAddDriver={handleAddDriver} onRemoveDriver={handleRemoveDriver} neighborhoodFees={neighborhoodFees} onUpdateFee={handleUpdateFee} onRemoveFee={handleRemoveFee} />;
      case 'inventory':
        return <Inventory inventory={inventory} onUpdateStock={handleUpdateStock} onUpdateIngredientName={handleUpdateIngredientName} onAddIngredient={handleAddIngredient} onRemoveIngredient={handleRemoveIngredient} onAddProduct={handleAddProduct} onRemoveProduct={handleRemoveProduct} products={products} onLogWaste={handleLogWaste} wasteLogs={wasteLogs} addOns={addOns} onAddAddOn={handleAddAddOn} onRemoveAddOn={handleRemoveAddOn} />;
      case 'crm':
        return <CRM customers={customers} onAddCustomer={handleAddCustomer} onRemoveCustomer={handleRemoveCustomer} />;
      case 'reports':
        return <Reports orders={orders} />;
      case 'settings':
        return <Settings settings={storeSettings} onUpdateSettings={setStoreSettings} coupons={coupons} onAddCoupon={handleAddCoupon} onRemoveCoupon={handleRemoveCoupon} />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] text-slate-800 font-sans overflow-hidden selection:bg-blue-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} selectedUnitName={selectedUnit.name} onChangeUnit={() => setSelectedUnit(null)} settings={storeSettings} />
      <main className="flex-1 ml-64 p-8 overflow-hidden h-screen relative">
         <div className="h-full animate-in fade-in slide-in-from-right-4 duration-500">{renderContent()}</div>
      </main>
    </div>
  );
}