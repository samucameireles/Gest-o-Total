import React, { useState } from 'react';
import { Bike, Plus, Trash2, Map, Save, X } from 'lucide-react';
import { Driver, NeighborhoodFee } from '../types';

interface MotoboysProps {
  drivers: Driver[];
  onAddDriver: (name: string) => void;
  onRemoveDriver: (id: string) => void;
  neighborhoodFees: NeighborhoodFee[];
  onUpdateFee: (neighborhood: string, price: number) => void;
  onRemoveFee: (id: string) => void;
}

export const Motoboys: React.FC<MotoboysProps> = ({ drivers, onAddDriver, onRemoveDriver, neighborhoodFees, onUpdateFee, onRemoveFee }) => {
  const [newDriverName, setNewDriverName] = useState('');
  const [newNeighborhood, setNewNeighborhood] = useState('');
  const [newFeePrice, setNewFeePrice] = useState('');

  const handleAddDriver = () => {
    if (newDriverName.trim()) {
      onAddDriver(newDriverName);
      setNewDriverName('');
    }
  };

  const handleAddFee = () => {
    if (newNeighborhood.trim() && newFeePrice) {
      onUpdateFee(newNeighborhood, parseFloat(newFeePrice));
      setNewNeighborhood('');
      setNewFeePrice('');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
      {/* Drivers List */}
      <div className="bg-white rounded-3xl shadow-premium border border-border overflow-hidden flex flex-col">
        <div className="p-6 border-b border-border bg-background">
          <h2 className="text-xl font-heading font-extrabold text-textPrimary flex items-center gap-2">
            <Bike className="text-accent" /> Equipe de Entregas
          </h2>
          <p className="text-sm text-textSecondary">Gerencie os motoboys e visualize históricos</p>
        </div>
        
        <div className="p-6 border-b border-border bg-white flex gap-2">
            <input 
              value={newDriverName}
              onChange={(e) => setNewDriverName(e.target.value)}
              placeholder="Nome do Motoboy"
              className="flex-1 bg-background border border-border rounded-xl px-4 py-3 outline-none focus:border-accent"
            />
            <button 
              onClick={handleAddDriver}
              className="bg-accent hover:bg-accentDark text-white px-6 rounded-xl font-bold flex items-center gap-2"
            >
              <Plus size={18} /> Adicionar
            </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {drivers.map(driver => (
              <div key={driver.id} className="p-5 bg-background border border-border rounded-2xl hover:shadow-md transition-shadow">
                 <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border border-border shadow-sm">
                           <Bike size={24} className="text-textSecondary"/>
                        </div>
                        <div>
                            <p className="font-bold text-textPrimary text-lg">{driver.name}</p>
                            <p className="text-xs text-textSecondary">
                              {driver.deliveriesCount} entregas | <span className="text-success font-bold">R$ {driver.commissionTotal.toFixed(2)}</span>
                            </p>
                        </div>
                    </div>
                    <button 
                       onClick={() => onRemoveDriver(driver.id)}
                       className="text-textSecondary hover:text-danger hover:bg-white p-2 rounded-full transition-colors"
                    >
                       <Trash2 size={20} />
                    </button>
                 </div>
                 
                 {/* History of IDs */}
                 <div className="bg-white rounded-lg p-3 border border-border">
                    <p className="text-[10px] text-textSecondary uppercase font-bold mb-2">Entregas Recentes (ID)</p>
                    <div className="flex flex-wrap gap-2">
                      {driver.history && driver.history.length > 0 ? (
                        driver.history.slice(-10).map((histId, idx) => (
                          <span key={idx} className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded font-mono font-bold">#{histId}</span>
                        ))
                      ) : (
                        <span className="text-xs text-textSecondary italic">Nenhuma entrega registrada.</span>
                      )}
                    </div>
                 </div>
              </div>
            ))}
        </div>
      </div>

      {/* Neighborhood Fees */}
      <div className="bg-white rounded-3xl shadow-premium border border-border overflow-hidden flex flex-col">
        <div className="p-6 border-b border-border bg-background">
          <h2 className="text-xl font-heading font-extrabold text-textPrimary flex items-center gap-2">
            <Map className="text-highlight" /> Taxas por Bairro
          </h2>
          <p className="text-sm text-textSecondary">Configure o valor da entrega por região</p>
        </div>

        <div className="p-6 border-b border-border bg-white flex gap-2">
            <input 
              value={newNeighborhood}
              onChange={(e) => setNewNeighborhood(e.target.value)}
              placeholder="Bairro"
              className="flex-[2] bg-background border border-border rounded-xl px-4 py-3 outline-none focus:border-accent"
            />
             <input 
              value={newFeePrice}
              onChange={(e) => setNewFeePrice(e.target.value)}
              placeholder="R$"
              type="number"
              className="flex-1 bg-background border border-border rounded-xl px-4 py-3 outline-none focus:border-accent"
            />
            <button 
              onClick={handleAddFee}
              className="bg-highlight hover:bg-yellow-600 text-white px-4 rounded-xl font-bold flex items-center gap-2"
            >
              <Save size={18} />
            </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2">
          <table className="w-full text-left border-collapse">
            <thead className="text-xs text-textSecondary uppercase bg-background font-bold">
               <tr>
                 <th className="p-4 rounded-tl-xl">Bairro</th>
                 <th className="p-4 text-center">Valor (R$)</th>
                 <th className="p-4 text-right rounded-tr-xl">Ação</th>
               </tr>
            </thead>
            <tbody>
              {neighborhoodFees.map(fee => (
                <tr key={fee.id} className="border-b border-border hover:bg-background/50">
                  <td className="p-4 font-medium text-textPrimary">{fee.name}</td>
                  <td className="p-4 text-center font-bold text-textPrimary">{fee.price.toFixed(2)}</td>
                  <td className="p-4 text-right">
                     <button 
                       onClick={() => onRemoveFee(fee.id)}
                       className="text-textSecondary hover:text-danger p-2 hover:bg-white rounded-lg transition-colors"
                     >
                       <X size={18}/>
                     </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {neighborhoodFees.length === 0 && (
            <div className="text-center p-8 text-textSecondary text-sm">Nenhuma taxa cadastrada.</div>
          )}
        </div>
      </div>
    </div>
  );
};