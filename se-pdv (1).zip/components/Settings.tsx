import React, { useState } from 'react';
import { StoreSettings, Coupon } from '../types';
import { Save, Store, Image as ImageIcon, Tag, Trash2, Plus } from 'lucide-react';

interface SettingsProps {
  settings: StoreSettings;
  onUpdateSettings: (s: StoreSettings) => void;
  coupons: Coupon[];
  onAddCoupon: (code: string, percent: number) => void;
  onRemoveCoupon: (id: string) => void;
}

export const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings, coupons, onAddCoupon, onRemoveCoupon }) => {
  const [name, setName] = useState(settings.name);
  const [logo, setLogo] = useState(settings.logoUrl);
  const [newCode, setNewCode] = useState('');
  const [newPercent, setNewPercent] = useState('');

  const handleSave = () => { onUpdateSettings({ name, logoUrl: logo }); alert("Salvo!"); };
  const handleAddCoupon = () => { if(newCode && newPercent) { onAddCoupon(newCode.toUpperCase(), parseFloat(newPercent)); setNewCode(''); setNewPercent(''); }};

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full overflow-y-auto pb-20">
      {/* Basic Info */}
      <div className="bg-white rounded-3xl shadow-premium border border-border p-8 h-fit">
         <h2 className="text-xl font-heading font-extrabold text-textPrimary mb-6 flex items-center gap-2"><Store size={20} className="text-accent"/> Dados da Unidade</h2>
         <div className="space-y-5">
             <div><label className="block text-xs font-bold text-textSecondary mb-1">Nome</label><input value={name} onChange={e => setName(e.target.value)} className="w-full bg-background border border-border rounded-xl p-3 outline-none focus:border-accent" /></div>
             <div><label className="block text-xs font-bold text-textSecondary mb-1">Logo URL</label><input value={logo} onChange={e => setLogo(e.target.value)} className="w-full bg-background border border-border rounded-xl p-3 outline-none focus:border-accent" /></div>
             <button onClick={handleSave} className="w-full bg-accent text-white font-bold py-3 rounded-xl shadow-lg mt-2 flex items-center justify-center gap-2"><Save size={18}/> Salvar</button>
         </div>
      </div>

      {/* Coupons */}
      <div className="bg-white rounded-3xl shadow-premium border border-border p-8 h-fit">
         <h2 className="text-xl font-heading font-extrabold text-textPrimary mb-6 flex items-center gap-2"><Tag size={20} className="text-highlight"/> Cupons de Desconto</h2>
         <div className="flex gap-2 mb-6 bg-background p-4 rounded-xl border border-border">
             <input value={newCode} onChange={e => setNewCode(e.target.value)} placeholder="CÓDIGO" className="flex-[2] bg-white border border-border rounded-lg p-2 outline-none uppercase font-bold" />
             <input value={newPercent} onChange={e => setNewPercent(e.target.value)} placeholder="%" type="number" className="flex-1 bg-white border border-border rounded-lg p-2 outline-none" />
             <button onClick={handleAddCoupon} className="bg-success text-white p-2 rounded-lg"><Plus size={20}/></button>
         </div>
         <div className="space-y-3">
             {coupons.map(c => (
                 <div key={c.id} className="flex justify-between items-center p-3 border border-dashed border-border rounded-xl hover:bg-gray-50">
                     <div><span className="font-bold text-textPrimary block">{c.code}</span><span className="text-xs text-success font-bold">{c.discountPercent}% OFF</span></div>
                     <button onClick={() => onRemoveCoupon(c.id)} className="text-gray-400 hover:text-danger"><Trash2 size={18}/></button>
                 </div>
             ))}
         </div>
      </div>
    </div>
  );
};