import React from 'react';
import { LayoutDashboard, ShoppingCart, ChefHat, Truck, Box, Settings, Store, Bike, Users } from 'lucide-react';
import { StoreSettings } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedUnitName: string;
  onChangeUnit: () => void;
  settings: StoreSettings;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, selectedUnitName, onChangeUnit, settings }) => {
  const menuItems = [
    { id: 'pos', label: 'Frente de Caixa', icon: ShoppingCart },
    { id: 'kitchen', label: 'Cozinha (KDS)', icon: ChefHat },
    { id: 'logistics', label: 'Expedição', icon: Truck },
    { id: 'motoboys', label: 'Gestão Motoboys', icon: Bike },
    { id: 'inventory', label: 'Estoque e Menu', icon: Box },
    { id: 'crm', label: 'Clientes (CRM)', icon: Users },
    { id: 'reports', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  return (
    <div className="w-64 bg-surface border-r border-border flex flex-col h-full fixed left-0 top-0 z-50 shadow-sm">
      <div className="p-8 flex flex-col items-center border-b border-border">
        <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center shadow-lg mb-3 overflow-hidden border border-border">
           {settings.logoUrl ? (
             <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-cover" />
           ) : (
             <span className="font-heading font-bold text-accent text-2xl">SE</span>
           )}
        </div>
        <h1 className="font-heading font-extrabold text-lg text-textPrimary tracking-tight text-center">{settings.name}</h1>
      </div>

      <div className="px-4 py-4">
        <button 
          onClick={onChangeUnit}
          className="w-full flex items-center gap-3 p-3 bg-background border border-border rounded-lg text-sm text-textPrimary hover:border-accent transition-colors"
        >
          <div className="bg-white p-1 rounded shadow-sm">
            <Store size={16} className="text-accent" />
          </div>
          <div className="flex-1 text-left">
             <p className="font-bold text-xs uppercase text-textSecondary">Unidade</p>
             <p className="font-bold truncate">{selectedUnitName}</p>
          </div>
        </button>
      </div>

      <nav className="flex-1 px-4 space-y-1 mt-2 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-accent/10 text-accent font-bold' 
                  : 'text-textSecondary hover:bg-background hover:text-textPrimary'
              }`}
            >
              <item.icon size={20} className={`${isActive ? 'text-accent' : 'text-gray-400 group-hover:text-textPrimary'}`} />
              <span className="text-sm">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-6 border-t border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-highlight flex items-center justify-center text-white text-xs font-bold shadow-md">
            OP
          </div>
          <div>
            <p className="text-sm font-bold text-textPrimary">Gerente</p>
            <p className="text-xs text-success">Sistema Ativo</p>
          </div>
        </div>
      </div>
    </div>
  );
};